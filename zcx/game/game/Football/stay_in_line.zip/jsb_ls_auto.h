//
//  jsb_ls_auto.h
//  jsb
//
//  Created by leafsoar on 8/1/13.
//
//

#ifndef jsb_jsb_ls_auto_h
#define jsb_jsb_ls_auto_h

#include "jsapi.h"
#include "jsfriendapi.h"
#include "ScriptingCore.h"

void register_all_ls(JSContext* cx, JSObject* obj);

#endif