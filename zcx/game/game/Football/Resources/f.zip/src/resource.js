var s_Bg = "res/bg.png";
var s_Bg1 = "res/bg1.png";
var s_Slider = "res/slider.png";
var s_Ball = "res/ball.png";
var s_Block = "res/block.png";
var s_Button = "res/button.png";
var s_ScoreBg = "res/score_bg.png";
var s_HighScoreBg = "res/high_score_bg.png";

var g_resources = [
    //image
    {src:s_Bg},
    {src:s_Bg1},
    {src:s_Slider},
    {src:s_Ball},
    {src:s_Block},
    {src:s_Button},
    {src:s_ScoreBg},
    {src:s_HighScoreBg}


    //plist

    //fnt

    //tmx

    //bgm

    //effect
];